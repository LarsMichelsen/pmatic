#!/usr/bin/env python
# encoding: utf-8
#
# pmatic - Python API for Homematic. Easy to use.
# Copyright (C) 2016 Lars Michelsen <lm@larsmichelsen.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""
This script computes the dew point (in degrees Celsius), if the current
values for temperature and humidity are given.

"""

import pmatic.utils as utils

temperature = 22.
humidity = 0.60

# The expected output from the following print statement is:
# Temperature (C):  22.0 , Humidity (%):  60.0 , Dew point (C):  13.8751835583

print "Temperature (C): ", temperature, ", Humidity (%): ", \
    humidity * 100., ", Dew point (C): ", utils.dew_point(temperature, humidity)
